{
    "name": "Apple",
    "price": 0.5,
    "stock": 100,
    "barcode": "111111"
}
